import random as rn
import numpy as np
from numpy.random import choice as np_choice

class AntColony(object):

    def __init__(self, distancias, n_ants, n_best, n_iter, cons_evap, alpha=1, beta=1):

        self.distancias  = distancias
        self.feromonas = np.ones(self.distancias.shape) / len(distancias)
        self.all_inds = range(len(distancias))
        self.n_ants = n_ants
        self.n_best = n_best
        self.n_iter = n_iter
        self.cons_evap = cons_evap
        self.alpha = alpha
        self.beta = beta

    def run(self):
        print("Matriz Inicial:",file=open('output.txt', 'a'))
        print(self.distancias,file=open('output.txt', 'a'))
        print("Matriz de Visibilidad:",file=open('output.txt', 'a'))
        print(1/self.distancias,file=open('output.txt', 'a'))
        print("Matriz de feromonas:",file=open('output.txt', 'a'))
        print(self.feromonas,"\n",file=open('output.txt', 'a'))

        shortest_path = None
        all_time_shortest_path = ("placeholder", np.inf)
        for i in range(self.n_iter):
            print("\nIteracion ",i+1,":",file=open('output.txt', 'a'))
            print("Matriz:",file=open('output.txt', 'a'))
            print(self.distancias,file=open('output.txt', 'a'))
            print("Matriz de Visibilidad:",file=open('output.txt', 'a'))
            print(1/self.distancias,file=open('output.txt', 'a'))
            print("Matriz de feromonas:",file=open('output.txt', 'a'))
            print(self.feromonas,"\n",file=open('output.txt', 'a'))
            
            all_paths = self.gen_all_paths()

            print("Hormigas: ",file=open('output.txt', 'a'))
            for pat in all_paths:
                print(pat,file=open('output.txt', 'a'))

            self.spread_pheronome(all_paths, self.n_best, shortest_path=shortest_path)
            shortest_path = min(all_paths, key=lambda x: x[1])
            print("Camino Elegido:",file=open('output.txt', 'a'))
            print (shortest_path,"\n",file=open('output.txt', 'a'))
            if shortest_path[1] < all_time_shortest_path[1]:
                all_time_shortest_path = shortest_path            
            self.feromonas * self.cons_evap            
        return all_time_shortest_path

    def spread_pheronome(self, all_paths, n_best, shortest_path):
        sorted_paths = sorted(all_paths, key=lambda x: x[1])
        for path, dist in sorted_paths[:n_best]:
            for move in path:
                self.feromonas[move]=0.1*0.5 +0.5*( 1/dist)

    def gen_path_dist(self, path):
        total_dist = 0
        for ele in path:
            total_dist += self.distancias[ele]
        return total_dist

    def gen_all_paths(self):
        all_paths = []
        for i in range(self.n_ants):
            path = self.gen_path(0)
            all_paths.append((path, self.gen_path_dist(path)))
        return all_paths

    def gen_path(self, start):
        path = []
        visited = set()
        visited.add(start)
        prev = start
        for i in range(len(self.distancias) - 1):
            move = self.pick_move(self.feromonas[prev], self.distancias[prev], visited)
            path.append((prev, move))
            prev = move
            visited.add(move)
        path.append((prev, start)) # going back to where we started    
        return path

    def pick_move(self, feromonas, dist, visited):
        feromonas = np.copy(feromonas)
        feromonas[list(visited)] = 0

        row = feromonas ** self.alpha * (( 1.0 / dist) ** self.beta)

        norm_row = row / row.sum()
        move = np_choice(self.all_inds, 1, p=norm_row)[0]
        return move
