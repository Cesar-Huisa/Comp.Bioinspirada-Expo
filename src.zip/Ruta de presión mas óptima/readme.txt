Se ejecuta una simulacion de supresion de presión para determinar la ruta que menos presion pierda en toda la ciudad lo cual ayuda a reducir costos y mejorar
la calidad de servicio sin contar que ayudaria a que el servicio de agua potable llegue a mas lugares sin problemas lo cual aportaria mucho a la comunidad

En la simulacion se usa el algoritmo Ant Colony System con una entrada en la que vendrian siendo la matriz de perdida de presión entre dos puntos de la ciudad
simulando las perdidad de presion comunes en un sistema hidraulico

EL resultado va al final del archivo de salida y nos indica la ruta de servicio a seguir con menor perdida de presion para que pueda ser tomanda en cuanta a la hora
de hacer un proyecto hidraulico en la cuidad