import numpy as np
import csv
from ant_colony import AntColony

oo=np.inf

def read_data(route):
    rt=[]
    with open(route) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        for c in csv_reader:
            tmp=[]
            for el in c:
                if el=='inf':
                    tmp.append(oo)
                else:
                    tmp.append(float(el))
            rt.append(tmp)
    return(np.array(rt))


matriz_ini=read_data("./data.csv")

n_iter=50

syst = AntColony(matriz_ini, 10, 1,n_iter, 0.99, alpha=1, beta=1)
camino_corto = syst.run()
print ("Numero de Iteraciones: ",n_iter)
print ("Mejor Hormiga Global: {}".format(camino_corto))