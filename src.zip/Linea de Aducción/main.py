import random

def verificar_vec(vec, limites):

    vec_new = []
    for i in range(len(vec)):

        if vec[i] < limites[i][0]:
            vec_new.append(limites[i][0])

        if vec[i] > limites[i][1]:
            vec_new.append(limites[i][1])

        if limites[i][0] <= vec[i] <= limites[i][1]:
            vec_new.append(vec[i])
        
    return vec_new


def main(cost_func, limites, popsize, mutate, recombination, maxiter):
    
    population = []
    for i in range(0,popsize):
        indv = []
        for j in range(len(limites)):
            indv.append(random.uniform(limites[j][0],limites[j][1]/2))
        population.append(indv)
            
    for i in range(1,maxiter+1):
        print("\n",file=open('output.txt', 'a'))
        print("Poblacion",file=open('output.txt', 'a'))
        for u in population:
            print(u,file=open('output.txt', 'a'))
        print("\n",file=open('output.txt', 'a'))
        
        print ('GENERATION:',i,file=open('output.txt', 'a'))

        gen_scores = []

        for j in range(0, popsize):

            candidates = list(range(0,popsize))
            candidates.remove(j)
            random_index = random.sample(candidates, 3)

            print ('\nIndividuo ',j,file=open('output.txt', 'a'))
            print("Individuos seleccionados: ",random_index,file=open('output.txt', 'a'))
            x_1 = population[random_index[0]]
            x_2 = population[random_index[1]]
            x_3 = population[random_index[2]]
            x_t = population[j]   

            x_diff = [x_2_i - x_3_i for x_2_i, x_3_i in zip(x_2, x_3)]
            print ("Vector de diferencia:",file=open('output.txt', 'a'))
            print(x_diff,file=open('output.txt', 'a'))

            v_donor = [x_1_i + mutate * x_diff_i for x_1_i, x_diff_i in zip(x_1, x_diff)]
            v_donor = verificar_vec(v_donor, limites)

            print ("Vector mutado:",file=open('output.txt', 'a'))
            print(v_donor,file=open('output.txt', 'a'))

            v_trial = []
            for k in range(len(x_t)):
                crossover = random.random()
                if crossover <= recombination:
                    v_trial.append(v_donor[k])

                else:
                    v_trial.append(x_t[k])

            print ("Vector trial:",file=open('output.txt', 'a'))
            print(v_trial,file=open('output.txt', 'a'))
                    
            score_trial  = cost_func(v_trial)
            score_target = cost_func(x_t)

            if score_trial < score_target:
                population[j] = v_trial
                gen_scores.append(score_trial)
                print("La aptitud mejora nos quedamos con el nuevo individuo",file=open('output.txt', 'a'))
                print( '   >',score_trial, v_trial,file=open('output.txt', 'a'))

            else:
                print("La aptitud no mejora nos quedamos con el antiguo individuo",file=open('output.txt', 'a'))
                print( '   >',score_target, x_t,file=open('output.txt', 'a'))
                gen_scores.append(score_target)

        gen_avg = sum(gen_scores) / popsize
        gen_best = min(gen_scores)
        gen_sol = population[gen_scores.index(min(gen_scores))]

        print('    > PROMEDIO:',gen_avg,file=open('output.txt', 'a'))
        print('    > MEJOR APTITUD:',gen_best,file=open('output.txt', 'a'))
        print('       > MEJOR SOLUCION:',gen_sol,'\n',file=open('output.txt', 'a'))

    return gen_sol


#Funcion
func= lambda x:32.535 /x
def funcf(x):
    return(func(x[0]))
#Rangos de variables
limites = [(4.07,637.98)]
#Nro Poblacion
popsize = 645
#Coef. de mutacion
mutate = 1.2
#Coef. de cruzamiento
recombination = 0.5
#Nro. de generaciones   
maxiter = 20

main(funcf, limites, popsize, mutate, recombination, maxiter)
