Los valores de entrada son los especificados en el documento el cual se uso para calcular las variables de aducción las cuales sirven de complemento a 
la hora de regularizar las redes hidraulicas en los calculos realizados por el autor

La salida es el valor de la Liena de Aducción calculada la cual conicide con la del usuario la cual puede ser verificada en img.jpg